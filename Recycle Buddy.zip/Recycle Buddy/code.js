var totPlastic = 0;
var totPaper = 0;
var totMetal = 0;
var totOther = 0;
var totItems = 0;
var commonItem = "";
onEvent("startBtn", "click", function( ) {
  setScreen("trashScreen");
});
onEvent("statsBtn", "click", function( ) {
  setScreen("statsScreen");
});
onEvent("leaderBtn", "click", function( ) {
  setScreen("leaderScreen");
});
onEvent("statstoHomeBtn", "click", function( ) {
  setScreen("homeScreen");
});
onEvent("trashtoHomeBtn", "click", function( ) {
  setScreen("homeScreen");
});
onEvent("leadertoHomeBtn", "click", function( ) {
  setScreen("homeScreen");
});
onEvent("addBtn", "click", function( ) {
  totPlastic = Number(getText("plasticBox")) + totPlastic;
  totPaper = Number(getText("paperBox")) + totPaper;
  totMetal = Number(getText("metalBox")) + totMetal;
  totOther = Number(getText("otherBox")) + totOther;
  totItems = ((totPlastic + totPaper) + totMetal) + totOther;
  setText("plasticlbl", totPlastic);
  setText("paperlbl", totPaper);
  setText("metallbl", totMetal);
  setText("otherlbl", totOther);
  setText("totallbl", totItems);
  setText("plasticBox", "");
  setText("metalBox", "");
  setText("paperBox", "");
  setText("otherBox", "");
  showElement("addedLBL");
  commonItem = getMax(totPlastic, totMetal, totPaper, totOther);
  setText("commonlbl", commonItem);
  
});
function getMax(plastic, metal, paper, other) {
  var max;
  if((plastic > metal) && (plastic > paper) && (plastic > other)){
    max = "plastic";
  }else if((metal > plastic) && (metal > paper) && (metal > other)){
    max = "metal";
  }else if((paper > metal) && (paper > plastic) && (paper > other)){
    max = "paper";
  }else{
    max = "other";
  }
  return max;
}
